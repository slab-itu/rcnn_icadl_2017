from __future__ import division

import argparse
import sys, time

import chainer
import chainer.optimizers
import chainer.serializers
import chainer.functions as F
from chainer import Variable
from chainer import cuda
import numpy as np
from model import LetterClassifyer
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_recall_fscore_support
import math
import random

def argument():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode')
    parser.add_argument('file')
    parser.add_argument('--embed', default=3000, type=int)
    parser.add_argument('--vocab', default=1000, type=int)
    parser.add_argument('--hidden', default=1000, type=int)
    parser.add_argument('--epoch', default=10, type=int)
    parser.add_argument('--model', default="model")
    parser.add_argument('--classes', default=2, type=int)
    parser.add_argument('--use-gpu', action='store_true', default=True)
    parser.add_argument('--unchain', action='store_true', default=False)
    args = parser.parse_args()
    return args


def letter_list(fname):
    with open(fname) as f:
        for l in f:
          body = l[:-3]
          val = int(l[-2])
          x = list(''.join(body.split()))
          x.append('</s>')
          yield x, val
def letter_list_text(t):
    x = list(''.join(t.split()))
    x.append('</s>')
    return x
# 
class Vocabulary:
    def __init__(self, fname):
        self.fname = fname
        self.l2i = {}
        self.i2l = []
        if not fname is None:
          self.load_vocab()
    def stoi(self, letter):
        if letter in self.l2i:
          return self.l2i[letter]
        return self.l2i['<unk>']
    def itos(self, id):
        if id < len(self.i2l):
            return self.i2l[id]
        return '<unk>'
            
    def append_letter(self, l):
        if l in self.l2i:
          return
        self.i2l.append(l)
        id = len(self.i2l) -1
        self.l2i[l] = id
    def load_vocab(self):
        self.append_letter('<unk>')
        self.append_letter('<s>')
        self.append_letter('</s>')
        with open(self.fname) as f:
          for line in f:
            nline = line[:-3]
            for l in nline:
              self.append_letter(l)

    def save_vocab(self, filename):
        with open(filename, 'w') as f:
          for l in self.i2l:
            f.write(l + "\n")
    @staticmethod
    def load_from_file(filename):
        vocab = Vocabulary(None)
        with open(filename) as f:
          for l in f:
            l = l[:-1]
            vocab.append_letter(l)
        return vocab

def forward(src_batch, t, model, is_training, vocab, xp):
    batch_size = len(src_batch)
    src_len = len(src_batch[0])
    src_stoi = vocab.stoi
    x_batch = [Variable(xp.asarray([[src_stoi(x)]], dtype=xp.int32)) for x in src_batch[0]]
    y = model.forward(x_batch)
    if is_training:
      t = Variable(xp.asarray([t], dtype=xp.int32))
      # t = xp.array(F.broadcast_to(xp.array([t]),(1,1)), dtype=xp.int32)
      loss = F.sigmoid_cross_entropy(y.data[0], t)
      acc = F.accuracy(y, t)
      return y, acc, loss
    else:
      return y
        
def train(args):
    if args.use_gpu:
        xp = cuda.cupy
        cuda.get_device(0).use()
    else:
        xp = np
    vocab = Vocabulary(args.file)
    m = LetterClassifyer(args.vocab, args.embed, args.hidden, args.classes)
    m.zerograds()
    if args.use_gpu:
      m.to_gpu()
    time_t = 10
    
    f = open("evaluation_results_training.csv", "w")
    f.write("Accuracy, Precision, Recall, F-measure\n")
    f.flush()
    
    validation_stats = open("validation_stats.csv", "w")
    validation_stats.write("Accuracy, Precision, Recall, F-measure\n")
    validation_stats.flush()


    train_stats = open("training_data_stats.txt", "w")
    
    training_data_embedding = []
    training_data_labels = []
    for chars_line, label in letter_list(args.file):
      training_data_embedding.append(chars_line)
      training_data_labels.append(label)
      # training_data.append([chars_line, label])
    
    #training_data_embedding = xp.array(training_data_embedding)
    #training_data_labels = xp.array(training_data_labels)

    positive_values_mask = (training_data_labels == 1)
    negative_values_mask = (training_data_labels == 0)
    postive_data = training_data_embedding[positive_values_mask]
    postive_data_labels = training_data_labels[positive_values_mask]

    negative_data = training_data_embedding[negative_values_mask]
    negative_data_labels = training_data_labels[negative_values_mask]

    # training_data = dstack(training_data_embedding, training_data_labels)
    training_data = zip(training_data_embedding, training_data_labels)
    total_instances = len(training_data)
    
    # We will include these number of instances in our training from both classes
    num_training_unit_instances = len(postive_data) if ( ((total_instances * 0.8) / 2) >= len(postive_data)) else ((total_instances * 0.8) / 2) 
    num_training_unit_instances = int(math.floor(num_training_unit_instances))
    num_training_instances = num_training_unit_instances * 2 # 2 classes
    num_validation_instances = total_instances - num_training_instances

    random_true = xp.broadcast_to(True, (int(math.floor(num_training_unit_instances))))
    random_false = xp.broadcast_to(False, (int(math.floor(total_instances - num_training_unit_instances))))
    unit_training_mask = xp.concatenate((random_true, random_false),axis = 0)

    training_data_indces = [i for i, x in enumerate(unit_training_mask) if x == True]
    # print("Indeces: ", training_data_indces)
    
    validation_mask = xp.broadcast_to(True, (int(math.floor(len(postive_data))),))
    validation_mask.setflags(write=1)
    validation_mask[training_data_indces] = False

    # unit_training_mask = xp.random.choice(a=[False, True], size=(num_training_unit_instances,), p=[0.5, 0.5]) 
    postive_training_instances = postive_data[unit_training_mask,:]
    negative_training_instances = negative_data[unit_training_mask,:]
    
    training_instances = xp.concatenate((postive_training_instances, negative_training_instances), axis=0)
    training_instances = random.sample(training_instances, len(training_instances))
    training_instances = xp.array(training_instances)

    num_validation_unit = len(postive_data) * 0.2
    random_true_validation = xp.broadcast_to(True, (int(math.floor(num_validation_unit)),))
    random_false_validation = xp.broadcast_to(False, (int(math.floor(num_validation_unit)),))
    unit_training_mask = xp.concatenate((random_true_validation, random_false_validation),axis = 0)

    validation_positive_instances = postive_data[unit_training_mask,:]
    validation_negative_instances = negative_data[unit_training_mask,:]
    
    validation_instances = xp.concatenate((validation_positive_instances, validation_negative_instances), axis=0)
    validation_instances = random.sample(validation_instances, len(validation_instances))
    validation_instances = xp.array(validation_instances)

    # Now we have to select validation data i.e the remaining data of training 
    # To do so we have to replace True with false and false with true in 
    # the array named unit_training_mask
    # print("True Indexes: \n", xp.argwhere(unit_training_mask == True))
    # print("Random True: ", random_true)
    # print("Random False: ", random_false)
    # print("Total Instances: ", total_instances)
    # print("Positive: ", postive_data.shape)
    # print("Negative: ", negative_data.shape)
    # print("Unit instances selected. ", num_training_unit_instances)
    # print("Positive Instances Selected for training:", postive_training_instances.shape)
    # print("Negative Instances Selected for training:", negative_training_instances.shape)
    # print("Type of Training data:", type(training_instances))
    # print("Training Instances Selected: ", training_instances[:,1])
    train_stats.write("Training Data \n")
    train_stats.write("Total Number of Positive Instances: " + str(len(postive_training_instances)) + "\n")
    train_stats.write("Total Number of Negative Instances: " + str(len(negative_training_instances)) + "\n")
    train_stats.write("Total Number of Training Examples: " + str(len(training_instances)) + "\n")
    train_stats.write("Validation Data \n")
    train_stats.write("Number of postive validation instances: " + str(len(validation_positive_instances)) + "\n")
    train_stats.write("Number of negative validation instances: " + str(len(validation_negative_instances)) + "\n")
    train_stats.write("Number of total validation instances: " + str(len(validation_instances)) + "\n")

    train_stats.flush()
    train_stats.close()



    for e in range(args.epoch):
      # We use this for calculation of precision and recall
      ground_truth = []
      pred_label = []

      opt = chainer.optimizers.Adam(alpha=0.001)
      opt.setup(m)
      opt.add_hook(chainer.optimizer.GradientClipping(5.0))
      print("epoch: %d" % e)
      i =0
      total_acc = 0
      e_acc = 0.0
      for x_batch, y in training_instances:
        x_batch = [x_batch]
        output, acc, loss = forward(x_batch, y, m, True, vocab, xp)
        probability_using_sigmoid = (1 / (1 + math.exp(output.data[0][0])))
        predicted_label = 0
        if (probability_using_sigmoid > 0.5):
          predicted_label = 1
        print("Epoch: ", e, " Actual Label: ", y, " Predicted Label: ", predicted_label)
        ground_truth.append(y)
        pred_label.append(predicted_label)
        total_acc += acc
        e_acc += acc
        # print("time: %d, accuracy %f loss %f" % (i, acc.data, loss.data))
        if i % time_t == 0:
          if i != 0:
            total_acc /= time_t
            total_acc = 0
        loss.backward()
        if args.unchain:
          loss.unchain_backward()
        opt.update()
        i += 1
        sys.stdout.flush()
      prfs = precision_recall_fscore_support(ground_truth, pred_label, average='weighted')
      CM = confusion_matrix(ground_truth, pred_label)
      e_acc = ((CM[0][0] + CM[1][1]) / (CM[0][0] + CM[0][1] + CM[1][0] + CM[1][1]))

      f.write(str(e_acc) + "," + str(prfs[0]) + "," + str(prfs[1]) + "," + str(prfs[2]) + "\n")
      f.flush()

      # Check Model on validation data
      pred_label_validation = []   #initializing array for output labels
      ground_truth_validation = []   #initializing array for ground truth labels
      print("-----------Validation--------------")
      for x_batch, y in letter_list(args.file):
        x_batch = [x_batch]
        ground_truth_validation.append(y)
        output = forward(x_batch, None, m, False, vocab, xp)

        # Compute output using sigmoid
        probability_using_sigmoid = (1 / (1 + math.exp(output.data[0][0])))
        predicted_label = 0
        if (probability_using_sigmoid > 0.5):
          predicted_label = 1      
        pred_label_validation.append(predicted_label)  # appending to list of output labels
        print("Actual Label: ", y, " Predicted Label: ", predicted_label)

      prfs = precision_recall_fscore_support(ground_truth_validation, pred_label_validation, average='weighted')
      CM = confusion_matrix(ground_truth_validation, pred_label_validation)
      validation_accuracy = ((CM[0][0] + CM[1][1]) / (CM[0][0] + CM[0][1] + CM[1][0] + CM[1][1]))
      validation_stats.write(str(validation_accuracy) + "," + str(prfs[0]) + "," + str(prfs[1]) + "," + str(prfs[2]) + "\n")
      validation_stats.flush()

      chainer.serializers.save_hdf5("model_new/" + args.model + str(e) + ".hdf5", m)
      vocab.save_vocab("model_new/" + args.model + str(e) + ".vocab")
    
    f.close()
    validation_stats.close()
def eval(args):
    f = open("evaluation_results_testing.csv", "a")
    f.write("Accuracy,Precision,Recall,FMeasure\n")
    f.flush()
    if args.use_gpu:
        xp = cuda.cupy
        cuda.get_device(0).use()
    else:
        xp = np
    m = LetterClassifyer(args.vocab, args.embed, args.hidden, args.classes)
    for e in [99]:
        # model_name = "model_new/model" + str(e) + ".hdf5"
        # vocab_name = "model_new/model" + str(e) + ".vocab"
        # print model_name
        # print vocab_name
        chainer.serializers.load_hdf5("models/model99.hdf5", m)
        vocab = Vocabulary.load_from_file("model.vocab")
        # vocab = Vocabulary.load_from_file(vocab_name)
        # chainer.serializers.load_hdf5(model_name, m)
        # vocab = Vocabulary.load_from_file(vocab_name)
        if args.use_gpu:
            m.to_gpu()

        pred_label = []		#initializing array for output labels
        test_label = []		#initializing array for ground truth labels
        iters = 0
        for x_batch, y in letter_list(args.file):
          iters += 1		
          x_batch = [x_batch]
          test_label.append(y)
          output = forward(x_batch, None, m, False, vocab, xp)
          #print(output.data)
          #print("iteration: ", iters)		
          
          # print("hyp: %d" % np.argmax(output.data)) # label
          pred_label.append(int(((np.argmax(output.data)))))	# appending to list of output labels
          #print(type(pred_label))
          #print("actual label: ", test_label, " --- actual predict : ", pred_label)

        # prfs means precision, recall, fmeasure, support
        prfs = precision_recall_fscore_support(test_label, pred_label, average='weighted')
        # print("Precision: \n", prfs[0])
        # print("Recall: \n", prfs[1])
        # print("FMeasure: \n", prfs[2])
        # print("Support: \n", prfs[3])
        CM = confusion_matrix(test_label, pred_label)
        # print("Confusion Matrix: \n", CM)
        # print("[0][0]", CM[0][0])
        # print("[0][1]", CM[0][1])
        # print("[1][0]", CM[1][0])
        # print("[1][1]", CM[1][1])
        # print("Sum",(CM[0][0] + CM[1][1]))
        acc = ((CM[0][0] + CM[1][1]) / (CM[0][0] + CM[0][1] + CM[1][0] + CM[1][1])) 
        # print("Accuracy = ", acc)
        # print("------------------------------------------------")
        f.write(str(acc) + "," + str(prfs[0]) + "," + str(prfs[1]) + "," + str(prfs[2]) + "\n")
        f.flush()
    f.close()

### Original code chunk ###
#    x_batch = [letter_list_text(args.file)]
#    output = forward(x_batch, None, m, False, vocab, xp)
#    print(output.data)
#    print("hyp: %d" % np.argmax(output.data)) # label
### Original code chunk ends ###

def main():
    args = argument()
    if args.mode == 'train':
        train(args)
    else:
        eval(args)

if __name__ == '__main__':
    main()
#

